import os
import pandas as pd
from tqdm import tqdm

def merge_csv_files(root_dir, output_file):
    all_dfs = []
    columns = None
    file_paths = []

    for state_dir in os.listdir(root_dir):
        state_path = os.path.join(root_dir, state_dir)
        if os.path.isdir(state_path) and state_dir.startswith('state_grp_'):
            for dirpath, _, filenames in os.walk(state_path):
                for filename in filenames:
                    if filename.endswith('_test_unique.csv'):
                        file_paths.append(os.path.join(dirpath, filename))

    for file_path in tqdm(file_paths, desc="Processing CSV files"):
        df = pd.read_csv(file_path)
        if columns is None:
            columns = df.columns
        else:
            df.columns = columns  
        all_dfs.append(df)

    if all_dfs:
        merged_df = pd.concat(all_dfs, ignore_index=True)
        merged_df.to_csv(output_file, index=False)
        print(f"Merged CSV saved to {output_file}")
    else:
        print(f"No _test_unique.csv files found in {root_dir}")


root_dir = '/disk_5/grid_v2_vm_data/disk_4/pre_processed_data/'
output_file = '/disk_4/uddeshya/Test-merge/merged_test_unique_sample.csv'


merge_csv_files(root_dir, output_file)



