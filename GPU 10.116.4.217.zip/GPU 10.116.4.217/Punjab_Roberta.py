import os
import torch
import pickle
import torch.nn.functional as F
from torch.utils.data import DataLoader
from sentence_transformers import SentenceTransformer, losses, SentencesDataset, InputExample, models
from transformers import AutoTokenizer, AutoModel
import numpy as np
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.spatial.distance import euclidean



model_dir = "/home/uddeshya.singh/R-model(MLM-pan)/pan_india_train_threshold_save_dir"

#model_dir = "/home/uddeshya.singh/Experiments/punjab_roberta_model2.1/checkpoint_epoch_Con1"

print("Model as the baseline :" , model_dir)

tokenizer = AutoTokenizer.from_pretrained(model_dir)
base_model = AutoModel.from_pretrained(model_dir)
print("Model and tokenizer loaded successfully")

num_gpus = torch.cuda.device_count()
print(f"Number of GPUs available: {num_gpus}")

if num_gpus > 0:
    base_model = base_model.cuda()

def get_embedding(text):
    inputs = tokenizer(text, return_tensors='pt')
    with torch.no_grad():
        outputs = base_model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).detach().cpu().numpy()


#input_pickle_path = '/home/uddeshya.singh/DataSet_triplet/PUNJAB_05_without_city.pkl'

# input_pickle_path = '/home/uddeshya.singh/DataSet_triplet/combined_triplets_PUNJAB_10.pkl'

input_pickle_path = '/home/uddeshya.singh/Triplet(9,10,11)/PUNJAB_03_combined_shuffled.pkl'
print(input_pickle_path)

with open(input_pickle_path, 'rb') as f:
    data = pickle.load(f)

triplets = data.get('triplets', [])
addresses = data.get('addresses', [])
lat_lngs = data.get('lat_lngs', [])

print(f"Length of triplets: {len(triplets)}, {triplets[:5]}")
print(f"Length of addresses: {len(addresses)}, {addresses[:5]}")
print(f"Length of lat_lngs: {len(lat_lngs)}, {lat_lngs[:5]}")



save_directory = './punjab_combined_triplet_train(amazon)'
print("Saving Directory:",save_directory)
if not os.path.exists(save_directory):
    os.makedirs(save_directory)

base_model.save_pretrained(save_directory)
tokenizer.save_pretrained(save_directory)

word_embedding_model = models.Transformer(model_name_or_path=save_directory, max_seq_length=100)
pooling_model = models.Pooling(word_embedding_model.get_word_embedding_dimension())
model = SentenceTransformer(modules=[word_embedding_model, pooling_model])




train_examples = [
    InputExample(texts=[addresses[anchor], addresses[positive], addresses[negative]], label=ring_level)
    for anchor, positive, negative, ring_level in triplets
]

train_dataset = SentencesDataset(train_examples, model)

print("DataSet Doneloading Done......................................")

def custom_collate_fn(batch):
    texts = []
    ring_levels = []
    for example in batch:
        texts.append(example.texts)
        ring_levels.append(example.label)
    return {'texts': texts, 'ring_levels': torch.tensor(ring_levels)}


train_dataloader = DataLoader(train_dataset, shuffle=True, batch_size=256, collate_fn=custom_collate_fn)


print("DataLoader Done...................................")
batch_size = 256
print("Batch_size:.............::::" , batch_size)

class ModifiedCustomTripletLoss(losses.TripletLoss):
    def __init__(self, model, margin=5.0):
        super(ModifiedCustomTripletLoss, self).__init__(model)
        self.margin = margin

    def forward(self, sentence_features, ring_levels):
        embeddings = [self.model(sentence_feature)['sentence_embedding'] for sentence_feature in sentence_features]
        anchor, positive, negative = embeddings
        margin_adjusted = self.margin * ring_levels
        return F.triplet_margin_loss(anchor, positive, negative, margin= margin_adjusted.mean()) 

# class ModifiedCustomTripletLoss(losses.TripletLoss):
#     def __init__(self, model, margin=5.0):
#         super(ModifiedCustomTripletLoss, self).__init__(model)
#         self.margin = margin

#     def forward(self, sentence_features, ring_levels):
#         embeddings = [self.model(sentence_feature)['sentence_embedding'] for sentence_feature in sentence_features]
#         anchor, positive, negative = embeddings
#         loss = 0.0
#         for i in range(len(anchor)):
#             margin_adjusted = self.margin * (ring_levels[i])
#             loss += F.triplet_margin_loss(anchor[i].unsqueeze(0), positive[i].unsqueeze(0), negative[i].unsqueeze(0), margin=margin_adjusted)
#         return loss / len(anchor)


# class ModifiedCustomTripletLoss(losses.TripletLoss):
#     def __init__(self, model, margin=5.0, band_ranges=None):
#         super(ModifiedCustomTripletLoss, self).__init__(model)
#         self.margin = margin
#         self.band_ranges = band_ranges if band_ranges else [(10, 15), (20, 25), (40, 50)]

#     def forward(self, sentence_features, ring_levels):
#         embeddings = [self.model(sentence_feature)['sentence_embedding'] for sentence_feature in sentence_features]
#         anchor, positive, negative = embeddings
#         loss = 0.0
#         for i in range(len(anchor)):
#             min_dist, max_dist = self.band_ranges[ring_levels[i] - 1]
#             margin = self.margin * 2 ** (ring_levels[i])  # Adjust margin based on ring level
#             d_ap = F.pairwise_distance(anchor[i].unsqueeze(0), positive[i].unsqueeze(0))
#             d_an = F.pairwise_distance(anchor[i].unsqueeze(0), negative[i].unsqueeze(0))

#             d_an = d_an.squeeze()
#             min_dist = torch.tensor(min_dist, device=d_an.device).float().squeeze()
#             max_dist = torch.tensor(max_dist, device=d_an.device).float().squeeze()

#             if d_an < min_dist:
#                 loss += ((min_dist - d_an) ** 2).sum()
#             elif d_an > max_dist:
#                 loss += ((d_an - max_dist) ** 2).sum()

#             loss += F.triplet_margin_loss(anchor[i].unsqueeze(0), positive[i].unsqueeze(0), negative[i].unsqueeze(0), margin=margin)

#         return loss / len(anchor)





margin = 5.0
num_epochs = 10
print("margin:",margin,"epochs:",num_epochs)
train_loss = ModifiedCustomTripletLoss(model=model, margin=margin)


for epoch in range(num_epochs):
    model.fit(train_objectives=[(train_dataloader, train_loss)], epochs=1, warmup_steps=5)
    checkpoint_path = os.path.join(save_directory, f'checkpoint_epoch_am{epoch + 1}')
    model.save(checkpoint_path)
    print(f"Epoch {epoch + 1} complete. Model saved to {checkpoint_path}")

print("Training complete.")
