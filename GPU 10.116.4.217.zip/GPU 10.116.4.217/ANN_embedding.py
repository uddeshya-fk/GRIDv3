import torch
from transformers import AutoModel, AutoTokenizer
from tqdm import tqdm
import numpy as np
from annoy import AnnoyIndex
import pickle

# print("10:42")
# checkpoint_path = '/home/uddeshya.singh/model_sentence_distilled-roberta-base'

print("12:08")
#checkpoint_path = "/home/uddeshya.singh/Experiments/punjab_combined_triplet_train(amazon)/checkpoint_epoch_am10"
checkpoint_path = "/home/uddeshya.singh/R-model(MLM-pan)/pan_india_train_threshold_save_dir"


def load_finetuned_model(checkpoint_path):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = AutoModel.from_pretrained(checkpoint_path)
    tokenizer = AutoTokenizer.from_pretrained(checkpoint_path)
    model = model.to(device)
    print("Loading done")
    return model, tokenizer, device

model, tokenizer, device = load_finetuned_model(checkpoint_path)

input_pickle_path = '/home/uddeshya.singh/DataSet_triplet/PUNJAB_1_for_lookup_without_city.pkl'

with open(input_pickle_path, 'rb') as f:
    data = pickle.load(f)
addresses = data.get('addresses', [])
lat_lngs = data.get('lat_lngs', [])

print(f"Length of addresses: {len(addresses)}, {addresses[-1]}")
print(f"Length of lat_lngs: {len(lat_lngs)}, {lat_lngs[-1]}")

def get_batch_embeddings(model, tokenizer, device, texts):
    inputs = tokenizer(texts, return_tensors='pt', padding=True, truncation=True)
    inputs = {k: v.to(device) for k, v in inputs.items()}
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).cpu().numpy()


def compute_embeddings_in_batches(model, tokenizer, device, addresses, batch_size=128):
    all_embeddings = []
    for i in tqdm(range(0, len(addresses), batch_size), desc="Computing embeddings"):
        batch_texts = addresses[i:i + batch_size]
        batch_embeddings = get_batch_embeddings(model, tokenizer, device, batch_texts)
        all_embeddings.append(batch_embeddings)
    return np.vstack(all_embeddings)
#embeddings_save_path = '/home/uddeshya.singh/DataSet_triplet/embeddings_ANN_1_without_city_model-roberta-base.pkl'
embeddings_save_path = '/home/uddeshya.singh/DataSet_triplet/embeddings_ANN_1_without_city_punjab_roberta-PAN.pkl'
print(embeddings_save_path)
embeddings = compute_embeddings_in_batches(model, tokenizer, device, addresses)


with open(embeddings_save_path, 'wb') as f:
    pickle.dump(embeddings, f)

print(f"Embeddings saved to {embeddings_save_path}")

with open(embeddings_save_path, 'rb') as f:
    loaded_embeddings = pickle.load(f)

print(f"Loaded embeddings shape: {loaded_embeddings.shape}")
