import torch
from transformers import AutoModel, AutoTokenizer
import numpy as np
import pickle
from sklearn.neighbors import KNeighborsClassifier
from sklearn_extra.cluster import KMedoids
import pandas as pd
from tqdm import tqdm
import h3
from geopy.distance import geodesic
import os
import time

#checkpoint_path = '/home/uddeshya.singh/Experiments/punjab_roberta_model_r_10'
#checkpoint_path = "/home/uddeshya.singh/DataSet_triplet/Roberta_classification_r"
#checkpoint_path = "/home/uddeshya.singh/Models/model-classification-r-checkpoint-260000"

checkpoint_path = "/home/uddeshya.singh/Experiments/punjab_combined_triplet_train(amazon)/checkpoint_epoch_am10"
#checkpoint_path =  "/home/uddeshya.singh/R-model(MLM-pan)/pan_india_train_threshold_save_dir"

#checkpoint_path = '/home/uddeshya.singh/model_sentence_distilled-roberta-base'

print('starting now ', time.strftime('%X %x %Z'))
k = 8
print(k)
print(checkpoint_path)
def load_finetuned_model(checkpoint_path):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = AutoModel.from_pretrained(checkpoint_path)
    tokenizer = AutoTokenizer.from_pretrained(checkpoint_path)
    model = model.to(device)
    print("Loading done")
    return model, tokenizer, device

model, tokenizer, device = load_finetuned_model(checkpoint_path)

input_pickle_path = "/home/uddeshya.singh/DataSet_triplet/PUNJAB_1_for_lookup_without_city.pkl"
with open(input_pickle_path, 'rb') as f:
    data = pickle.load(f)

# triplets_5 = data.get('triplets', [])
addresses_5 = data.get('addresses', [])
lat_lngs_5 = data.get('lat_lngs', [])

# print(f"Length of triplets: {len(triplets_5)}, {triplets_5[-1]}")
print(f"Length of addresses: {len(addresses_5)}, {addresses_5[-1]}")
print(f"Length of lat_lngs: {len(lat_lngs_5)}, {lat_lngs_5[-1]}")


# embeddings_save_path = "/home/uddeshya.singh/DataSet_triplet/embeddings_ANN_1_without_city_Roberta_triplet_l_10.pkl"
#embeddings_save_path = "/home/uddeshya.singh/DataSet_triplet/embeddings_ANN_1_without_city_model-classification-r10.pkl"
#embeddings_save_path = 'DataSet_triplet/embeddings_ANN_5_without_city_pan_india_test_base_roberta_4_epoch4.pkl'
#embeddings_save_path = '/home/uddeshya.singh/DataSet_triplet/embeddings_ANN_1_without_city_model-classification-r-checkpoint-260000.pkl'
#embeddings_save_path = '/home/uddeshya.singh/DataSet_triplet/embeddings_ANN_1_without_city_model-r-classification24-2600000.pkl'

embeddings_save_path = '/home/uddeshya.singh/DataSet_triplet/embeddings_ANN_1_without_city_triplet_train(amazon).pkl'
#embeddings_save_path = '/home/uddeshya.singh/DataSet_triplet/embeddings_ANN_1_without_city_punjab_roberta-PAN.pkl'
#embeddings_save_path = '/home/uddeshya.singh/DataSet_triplet/embeddings_ANN_1_without_city_model-roberta-base.pkl'

print(embeddings_save_path)
with open(embeddings_save_path, 'rb') as f:
    loaded_embeddings = pickle.load(f)

print(f"Loaded embeddings shape: {loaded_embeddings.shape}")

def get_batch_embeddings(model, tokenizer, device, texts):
    inputs = tokenizer(texts, return_tensors='pt', padding=True, truncation=True)
    inputs = {k: v.to(device) for k, v in inputs.items()}
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).cpu().numpy()


def compute_embeddings_in_batches(model, tokenizer, device, addresses, batch_size=128):
    all_embeddings = []
    for i in tqdm(range(0, len(addresses), batch_size), desc="Computing embeddings"):
        batch_texts = addresses[i:i + batch_size]
        batch_embeddings = get_batch_embeddings(model, tokenizer, device, batch_texts)
        all_embeddings.append(batch_embeddings)
    return np.vstack(all_embeddings)


#test_csv_path = '/home/uddeshya.singh/DataSet_triplet/combined_cleaned_triplet_test_PUNJAB_full_1.csv' 

test_csv_path = '/home/uddeshya.singh/Experiments/Test_100/Test_100.csv' 
test_df = pd.read_csv(test_csv_path)

test_addresses = test_df['cleaned_address'].tolist()
test_embeddings = compute_embeddings_in_batches(model, tokenizer, device, test_addresses)

from sklearn.neighbors import KNeighborsClassifier
import time

print('starting now ', time.strftime('%X %x %Z'))
nbrs = KNeighborsClassifier(n_neighbors=k)
nbrs.fit(loaded_embeddings, [0] * len(loaded_embeddings)) 
print('done now ', time.strftime('%X %x %Z'))


def get_knn_in_batches(knn, test_embeddings, batch_size=512):
    distances_list = []
    indices_list = []
    for i in tqdm(range(0, len(test_embeddings), batch_size), desc="Finding KNN"):
        batch_embeddings = test_embeddings[i:i + batch_size]
        distances, indices = knn.kneighbors(batch_embeddings)
        distances_list.append(distances)
        indices_list.append(indices)
    return np.vstack(distances_list), np.vstack(indices_list)


distances, indices = get_knn_in_batches(nbrs, test_embeddings) #

def compute_medoid(lat_lngs):
    kmedoids = KMedoids(n_clusters=1, method='pam', max_iter=0, random_state=0)
    kmedoids.fit(lat_lngs)
    return kmedoids.cluster_centers_[0]


medoids = []
for idx in tqdm(indices):
    neighbor_lat_lngs = [lat_lngs_5[i] for i in idx]
    medoid = compute_medoid(neighbor_lat_lngs)
    medoids.append(medoid)


test_df['pred_lat'] = [medoid[0] for medoid in medoids]
test_df['pred_lng'] = [medoid[1] for medoid in medoids]

def get_centroid_of_grid(grid_id_local): 
    try:
        return h3.h3_to_geo(grid_id_local)
    except Exception as e:
        print("Exception occurred", grid_id_local, e)
        return None

def get_deviation_for_df(lat_local, lng_local, centroid_local):
    try:
        return int(geodesic((lat_local, lng_local), centroid_local).meters)
    except Exception as e:
        print("Exception occurred", e)
        return None

def get_drift_for_row(row_local):
    """get drift between pred coordinates and lookup coordinates"""
    pred_coor = (row_local['pred_lat'], row_local['pred_lng'])
    pred_drift = get_deviation_for_df(row_local["lookup_lat"], row_local["lookup_lng"], pred_coor)
    return pred_drift

def get_accuracy_for_df(drift_list_local):
    accuracy_dict_local = {100: 0, 200: 0, 500: 0, 1000: 0, 2000: 0, "rest": 0, "None": 0}
    for i in drift_list_local:
        if i is None or pd.isnull(i):
            accuracy_dict_local["None"] += 1
            continue

        if i < 100:
            accuracy_dict_local[100] += 1
        elif i < 200:
            accuracy_dict_local[200] += 1
        elif i < 500:
            accuracy_dict_local[500] += 1
        elif i < 1000:
            accuracy_dict_local[1000] += 1
        elif i < 2000:
            accuracy_dict_local[2000] += 1
        else:
            accuracy_dict_local["rest"] += 1

    accuracy_dict_local[200] += accuracy_dict_local[100]
    accuracy_dict_local[500] += accuracy_dict_local[200]
    accuracy_dict_local[1000] += accuracy_dict_local[500]
    accuracy_dict_local[2000] += accuracy_dict_local[1000]

    accuracy_dict_per_local = {100: 0, 200: 0, 500: 0, 1000: 0, 2000: 0, "rest": 0, "None": 0}
    for k, v in accuracy_dict_local.items():
        accuracy_dict_per_local[k] = float(v) / max(1, (accuracy_dict_local[2000] + accuracy_dict_local["rest"]))

    final_accuracy_dict_local = {'num': accuracy_dict_local, 'per': accuracy_dict_per_local}
    return final_accuracy_dict_local

test_df['pred_drift'] = test_df.apply(lambda row: get_drift_for_row(row), axis=1)
test_drift_acc_dict = get_accuracy_for_df(test_df['pred_drift'].tolist())

print(test_drift_acc_dict)
print("BERT model evaluation")