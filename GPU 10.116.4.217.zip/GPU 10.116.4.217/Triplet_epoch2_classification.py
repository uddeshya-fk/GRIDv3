# import json
# import time
# import torch
# from transformers import AutoTokenizer, AutoModelForMaskedLM, AutoModelForSequenceClassification, DataCollatorWithPadding, Trainer, TrainingArguments
# import pandas as pd
# from datasets import load_dataset
# from tqdm import tqdm

# print('10:59')
# def load_finetuned_model(checkpoint_path, base_tokenizer_path):
#     device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#     model = AutoModelForMaskedLM.from_pretrained(checkpoint_path)
#     tokenizer = AutoTokenizer.from_pretrained(base_tokenizer_path)
#     model = model.to(device)
#     return model, tokenizer, device

# checkpoint_path = '/home/uddeshya.singh/Experiments/punjab_roberta_model_without_city_05/checkpoint_epoch2'
# model, tokenizer, device = load_finetuned_model(checkpoint_path, checkpoint_path)

# print("model" , checkpoint_path)

# address_data_path = '/home/uddeshya.singh/DataSet_triplet/classification_dataset/PUNJAB_with_grid_ids_train.csv'
# print('Loading dataset... ', time.strftime('%X %x %Z'))
# address_data_train = load_dataset("csv", data_files=address_data_path)
# print('Dataset loaded. ', time.strftime('%X %x %Z'))


# print('Preprocessing dataset... ', time.strftime('%X %x %Z'))
# address_data_train["train"] = address_data_train["train"].class_encode_column("grid_id")
# address_data_train = address_data_train.remove_columns(['addr_hash', 'lookup_lat', 'lookup_lng'])
# address_data_train = address_data_train.rename_column('grid_id', 'labels')

# class_label_feature = address_data_train['train'].features["labels"]
# num_labels = class_label_feature.num_classes
# class_names = class_label_feature.names
# print(f"Number of labels: {num_labels}")

# id2label = {i: label for i, label in enumerate(class_names)}
# id2label[len(class_names)] = 'None'
# label2id = {label: id for (id, label) in id2label.items()}

# save_dir = '/home/uddeshya.singh/DataSet_triplet/classification_dataset/ID_to_L'
# save_id2label = save_dir + '/id2label.json'
# with open(save_id2label, 'w') as f:
#     json.dump(id2label, f)

# save_label2id = save_dir + '/label2id.json'
# with open(save_label2id, 'w') as f:
#     json.dump(label2id, f)


# pretrained_tokenizer = tokenizer
# txt = "kadubeesanhalli salarpuria touch stone building"
# tokens = pretrained_tokenizer(txt)['input_ids']
# print(tokens)
# converted = pretrained_tokenizer.convert_ids_to_tokens(tokens)
# print(converted)


# def tokenize(batch):
#     tokenized_batch = pretrained_tokenizer(batch["cleaned_address"], padding=True, truncation=True, max_length=100)
#     return tokenized_batch


# print('Identifying issue rows... ', time.strftime('%X %x %Z'))
# none_ind_list = [i for i, a in tqdm(enumerate(address_data_train['train']['cleaned_address'])) if a is None or pd.isnull(a) or a == '']
# print(f"Found {len(none_ind_list)} issue rows.")


# new_address_data_train = address_data_train['train'].select(
#     i for i in range(len(address_data_train['train'])) if i not in set(none_ind_list)
# )


# print('Tokenizing dataset... ', time.strftime('%X %x %Z'))
# train_dataset = new_address_data_train.map(tokenize, batched=True, batch_size=100000, num_proc=7)
# train_dataset = train_dataset.remove_columns(['cleaned_address'])
# train_dataset.set_format("torch", columns=["input_ids", "attention_mask", "labels"])
# print('Dataset tokenized. ', time.strftime('%X %x %Z'))

# data_collator = DataCollatorWithPadding(tokenizer=pretrained_tokenizer)


# model_checkpoint = '/home/uddeshya.singh/Experiments/punjab_roberta_model_without_city_05/checkpoint_epoch2'
# with torch.cuda.device(2):
#     model = AutoModelForSequenceClassification.from_pretrained(model_checkpoint, num_labels=len(label2id))


# NO_OF_EPOCHS = 20
# fine_tuned_lm_trained_out_dir = '/home/uddeshya.singh/Experiments/Triplet_models_classification'
# print("Model will save to:",fine_tuned_lm_trained_out_dir)
# training_args = TrainingArguments(
#     output_dir=fine_tuned_lm_trained_out_dir,
#     overwrite_output_dir=True,
#     num_train_epochs=NO_OF_EPOCHS,
#     per_device_train_batch_size=128,
#     logging_steps=10000,
#     save_steps=20000,
#     save_total_limit=5
# )

# trainer = Trainer(
#     model=model,
#     args=training_args,
#     data_collator=data_collator,
#     tokenizer=pretrained_tokenizer,
#     train_dataset=train_dataset
# )


# print('Training model... ', time.strftime('%X %x %Z'))
# start_time = time.time()
# result = trainer.train()
# end_time = time.time()
# print('Training completed. ', time.strftime('%X %x %Z'))

# fine_tuned_lm_trained_save_dir = '/home/uddeshya.singh/Experiments/Triplet_models_classification_save'
# trainer.save_model(fine_tuned_lm_trained_save_dir)
# trainer.save_state()

# print(f"Total training time: {end_time - start_time} seconds")


import json
import time
import torch
from transformers import TextClassificationPipeline, AutoTokenizer, AutoModelForSequenceClassification, AutoModelForMaskedLM
import numpy as np
import pandas as pd
from h3 import h3
from geopy.distance import geodesic as vincenty
from tqdm import tqdm
from datasets import load_dataset

from transformers import AutoTokenizer
from transformers import DataCollatorForLanguageModeling
from transformers import AutoConfig, RobertaForMaskedLM
from transformers import Trainer, TrainingArguments
from transformers import pipeline
import time
from transformers import AutoModelForSequenceClassification, DataCollatorWithPadding
import torch

def load_finetuned_model(checkpoint_path, base_tokenizer_path):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = AutoModelForMaskedLM.from_pretrained(checkpoint_path)
    tokenizer = AutoTokenizer.from_pretrained(base_tokenizer_path)
    model = model.to(device)
    return model, tokenizer, device


checkpoint_path =  '/home/uddeshya.singh/Experiments/Model-Roberta-lm/Punjab_pan_india_train_threshold_save_dir'


model, tokenizer , device = load_finetuned_model(checkpoint_path, checkpoint_path)    
print(checkpoint_path)
pretrained_tokenizer = tokenizer
address_data_path = '/home/uddeshya.singh/DataSet_triplet/classification_dataset/PUNJAB_with_grid_ids_train.csv'
print('starting now ', time.strftime('%X %x %Z'))
address_data_train = load_dataset("csv", data_files=address_data_path)
print('completed now ', time.strftime('%X %x %Z'))



print('starting now ', time.strftime('%X %x %Z'))
address_data_train["train"] = address_data_train["train"].class_encode_column("grid_id")
print('starting now ', time.strftime('%X %x %Z'))
address_data_train = address_data_train.remove_columns(['addr_hash', 'lookup_lat', 'lookup_lng'])
print('starting now ', time.strftime('%X %x %Z'))
address_data_train = address_data_train.rename_column( 'grid_id', 'labels')
print('starting now ', time.strftime('%X %x %Z'))


class_label_feature = address_data_train['train'].features["labels"]

num_labels = class_label_feature.num_classes
class_names = class_label_feature.names
print(f"number of labels: {num_labels}")

id2label = {i: label for i, label in enumerate(class_names)}
id2label[len(class_names)] = 'None'

label2id = {label:id for (id,label) in id2label.items()}
print(len(id2label), len(label2id))

import json
save_dir = '/home/uddeshya.singh/DataSet_triplet/classification_dataset/ID_to_L'
save_id2label = save_dir +'/id2label.json'
with open(save_id2label, 'w') as f:
    json.dump(id2label, f)

save_label2id = save_dir +'/label2id.json'
with open(save_label2id, 'w') as f:
    json.dump(label2id, f)

txt = "kadubeesanhalli salarpuria touch stone building"
tokens = pretrained_tokenizer(txt)['input_ids']
print(tokens)
converted = pretrained_tokenizer.convert_ids_to_tokens(tokens)
print(converted)

def tokenize(batch):
    tokenized_batch = pretrained_tokenizer(batch["cleaned_address"], padding=True, truncation=True, max_length=100)#, is_split_into_words=True)
    return tokenized_batch


import pandas as pd
from tqdm import tqdm

# identify the issue rows
print('starting now ', time.strftime('%X %x %Z'))

none_ind_list = []
for i, a in tqdm(enumerate(address_data_train['train']['cleaned_address'])):
    if a is None or pd.isnull(a) or a=='':
        # print("a is None")
        none_ind_list.append(i)
        
print(len(none_ind_list), none_ind_list)

print('starting now ', time.strftime('%X %x %Z'))

# Exclude specific rows from the dataset

new_address_data_train = address_data_train['train'].select(
    (
        i for i in range(len(address_data_train['train'])) 
        if i not in set(none_ind_list)
    )
)

print('starting now ', time.strftime('%X %x %Z'))
new_address_data_train

print('starting now ', time.strftime('%X %x %Z'))
# train_dataset = address_data_train['train'].map(tokenize, batched=True, batch_size=10) #len(address_data_train['train']))
train_dataset = new_address_data_train.map(tokenize, batched=True, batch_size=100000, num_proc=4) #en(new_address_data_train))
train_dataset = train_dataset.remove_columns(['cleaned_address'])
train_dataset.set_format("torch", columns=["input_ids", "attention_mask", "labels"])
print('starting now ', time.strftime('%X %x %Z'))



from pynvml import *

def get_gpu_device_memory(device_index):
    nvmlInit()
    handle = nvmlDeviceGetHandleByIndex(device_index)
    info = nvmlDeviceGetMemoryInfo(handle)
    print(f"GPU Device {device_index} and memory occupied: {info.used//1024**2} MB.")

    memory = info.used//1024**2

def print_gpu_utilization():

    for d in [0,1,2,3]:
        get_gpu_device_memory(d)
    
    # nvmlInit()
    # handle = nvmlDeviceGetHandleByIndex(0)
    # info = nvmlDeviceGetMemoryInfo(handle)
    # print(f"GPU memory occupied: {info.used//1024**2} MB.")


def print_summary(result):
    print(f"Time: {result.metrics['train_runtime']:.2f}")
    print(f"Samples/second: {result.metrics['train_samples_per_second']:.2f}")
    print_gpu_utilization()


data_collator = DataCollatorWithPadding(tokenizer=pretrained_tokenizer)

print('starting now ', time.strftime('%X %x %Z'))

model_checkpoint = '/home/uddeshya.singh/Experiments/punjab_roberta_model_without_city_05/checkpoint_epoch2'

with torch.cuda.device(2):
    model = AutoModelForSequenceClassification.from_pretrained(model_checkpoint, num_labels=len(label2id))#.to("cuda")

print('starting now ', time.strftime('%X %x %Z'))
print_gpu_utilization()

NO_OF_EPOCHS = 10
fine_tuned_lm_trained_out_dir = '/home/uddeshya.singh/Experiments/Triplet_models_classification_2'
fine_tuned_lm_trained_save_dir = '/home/uddeshya.singh/Experiments/Triplet_models_classification_save_2'
print('starting now ', time.strftime('%X %x %Z'))
training_args = TrainingArguments(
 output_dir=fine_tuned_lm_trained_out_dir,
 overwrite_output_dir=True,
 num_train_epochs=NO_OF_EPOCHS,
 per_device_train_batch_size=128,
 logging_steps = 5000,
 save_steps=5000,
 save_total_limit=5,

    
#     gradient_accumulation_steps=4,
#     gradient_checkpointing=True,
#     gradient_checkpointing_kwargs={'use_reentrant':False},
#     fp16=True
    
    
#  evaluation_strategy="steps",
#  load_best_model_at_end=True
)

trainer = Trainer(
 model=model,
 args=training_args,
 data_collator=data_collator,
 tokenizer=pretrained_tokenizer,
 train_dataset=train_dataset
)
print('starting now ', time.strftime('%X %x %Z'))
print_gpu_utilization()


print('starting now ', time.strftime('%X %x %Z'))
start_time = time.time()
result = trainer.train()
end_time = time.time()
print('completed now ', time.strftime('%X %x %Z'))


trainer.save_model(fine_tuned_lm_trained_save_dir)
trainer.save_state()