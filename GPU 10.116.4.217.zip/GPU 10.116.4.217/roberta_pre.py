import pandas as pd
from datasets import Dataset
from transformers import AutoTokenizer
import torch
from transformers import AutoModelForMaskedLM, DataCollatorForLanguageModeling, Trainer, TrainingArguments
from transformers import RobertaTokenizerFast
import pickle

input_pickle_path = '/home/uddeshya.singh/DataSet_triplet/PUNJAB_5_for_lookup_without_city.pkl'

with open(input_pickle_path, 'rb') as f:
    data = pickle.load(f)

addresses = data.get('addresses', [])
lat_lngs = data.get('lat_lngs', [])

addresses_length = len(addresses)
lat_lngs_length = len(lat_lngs)

print(f"Length of addresses: {addresses_length},{addresses[-1]}")
print(f"Length of lat_lngs: {lat_lngs_length},{lat_lngs[-1]}")

data_dict = {"text": addresses}
dataset = Dataset.from_dict(data_dict)

tokenizer_path = "/home/devanapalli.ravi/disk_1/paper/data/gpu_re_trained_models/lm_retrained_models/pan_india_train_threshold/pan_india_train_threshold_out_dir_5_epochs/checkpoint-375000"  
tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)

def tokenize_function(examples):
    return tokenizer(examples["text"], truncation=True, padding="max_length", max_length=512)

tokenized_dataset = dataset.map(tokenize_function, batched=True, num_proc=None)

model_path = "/home/devanapalli.ravi/disk_1/paper/data/gpu_re_trained_models/lm_retrained_models/pan_india_train_threshold/pan_india_train_threshold_out_dir_5_epochs/checkpoint-375000"
model = AutoModelForMaskedLM.from_pretrained(model_path)
data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=True, mlm_probability=0.15)

print("taking_model",model_path)

training_args = TrainingArguments(
    output_dir='./results_new',          
    overwrite_output_dir=True,        
    num_train_epochs=2,               
    per_device_train_batch_size=2,   
    save_steps=10_000,                
    save_total_limit=2,
    logging_dir='./logs',            
    logging_steps=200,
    fp16=True,
)

trainer = Trainer(
    model=model,                       
    args=training_args,               
    data_collator=data_collator,       
    train_dataset=tokenized_dataset,   
)
epochs = 2
batch = 2 
print("Training begins.......")
print("For epochs:",epochs)
print("batch_size",batch)
trainer.train()

