import os
import torch
import pickle
import torch.nn.functional as F
from torch.utils.data import DataLoader
from sentence_transformers import SentenceTransformer, losses, SentencesDataset, InputExample, models
from transformers import AutoTokenizer, AutoModel
import numpy as np
import matplotlib.pyplot as plt

model_dir = "/home/devanapalli.ravi/disk_1/paper/data/gpu_re_trained_models/lm_retrained_models/pan_india_train_threshold/pan_india_train_threshold_out_dir_5_epochs/checkpoint-375000"

print("Model as the baseline :", model_dir)

tokenizer = AutoTokenizer.from_pretrained(model_dir)
base_model = AutoModel.from_pretrained(model_dir)
print("Model and tokenizer loaded successfully")

num_gpus = torch.cuda.device_count()
print(f"Number of GPUs available: {num_gpus}")

if num_gpus > 0:
    base_model = base_model.cuda()

def get_embedding(text):
    inputs = tokenizer(text, return_tensors='pt')
    with torch.no_grad():
        outputs = base_model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).detach().cpu().numpy()

input_pickle_path = '/home/uddeshya.singh/DataSet_triplet/PUNJAB_05_without_city.pkl'

with open(input_pickle_path, 'rb') as f:
    data = pickle.load(f)

triplets = data.get('triplets', [])
addresses = data.get('addresses', [])
lat_lngs = data.get('lat_lngs', [])

print(f"Length of triplets: {len(triplets)}, {triplets[:5]}")
print(f"Length of addresses: {len(addresses)}, {addresses[:5]}")
print(f"Length of lat_lngs: {len(lat_lngs)}, {lat_lngs[:5]}")

save_directory = './punjab_roberta_model_without_city_05'
print("Saving Directory:", save_directory)
if not os.path.exists(save_directory):
    os.makedirs(save_directory)

base_model.save_pretrained(save_directory)
tokenizer.save_pretrained(save_directory)

word_embedding_model = models.Transformer(model_name_or_path=save_directory, max_seq_length=256)
pooling_model = models.Pooling(word_embedding_model.get_word_embedding_dimension())
model = SentenceTransformer(modules=[word_embedding_model, pooling_model])

train_examples = [
    InputExample(texts=[addresses[anchor], addresses[positive], addresses[negative]], label=ring_level)
    for anchor, positive, negative, ring_level in triplets
]

train_dataset = SentencesDataset(train_examples, model)

print("Dataset loading done...")

def custom_collate_fn(batch):
    texts = []
    ring_levels = []
    for example in batch:
        texts.append(example.texts)
        ring_levels.append(example.label)
    return {'texts': texts, 'ring_levels': torch.tensor(ring_levels)}

train_dataloader = DataLoader(train_dataset, shuffle=True, batch_size=64, collate_fn=custom_collate_fn)

print("Dataloader done...")
batch_size = 64
print("Batch size:", batch_size)

class ModifiedCustomTripletLoss(losses.TripletLoss):
    def __init__(self, model, margin=5.0):
        super(ModifiedCustomTripletLoss, self).__init__(model)
        self.margin = margin

    def forward(self, sentence_features, ring_levels):
        embeddings = [self.model(sentence_feature)['sentence_embedding'] for sentence_feature in sentence_features]
        anchor, positive, negative = embeddings
        loss = 0.0
        for i in range(len(anchor)):
            margin_adjusted = self.margin * ring_levels[i]
            loss += F.triplet_margin_loss(anchor[i].unsqueeze(0), positive[i].unsqueeze(0), negative[i].unsqueeze(0), margin=margin_adjusted)
        return loss / len(anchor)

margin = 5.0
num_epochs = 5
print("Margin:", margin, "Epochs:", num_epochs)
train_loss = ModifiedCustomTripletLoss(model=model, margin=margin)

loss_values = []
iter_count = 0

def plot_loss_curve(loss_values, save_path):
    plt.figure()
    plt.plot(loss_values, label='Training Loss')
    plt.xlabel('Iterations')
    plt.ylabel('Loss')
    plt.title('Loss Curve')
    plt.legend()
    plt.savefig(save_path)
    plt.close()

for epoch in range(num_epochs):
    model.fit(train_objectives=[(train_dataloader, train_loss)], epochs=1, warmup_steps=10, show_progress_bar=False)
    for batch in train_dataloader:
        loss = train_loss(batch['texts'], batch['ring_levels'])
        loss_values.append(loss.item())
        iter_count += 1

        if iter_count % 500 == 0:
            print(f"Iteration {iter_count}, Loss: {loss.item()}")

        if iter_count % 1000 == 0:
            plot_path = os.path.join(save_directory, f'loss_curve_iter{iter_count}.png')
            plot_loss_curve(loss_values, plot_path)

    checkpoint_path = os.path.join(save_directory, f'checkpoint_epoch{epoch + 1}')
    model.save(checkpoint_path)
    print(f"Epoch {epoch + 1} complete. Model saved to {checkpoint_path}")

print("Training complete.")
